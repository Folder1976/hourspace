<?php
// Text
$_['text_paid_amazon'] = 'שולם באמצעות אמזון ארה״ב';
$_['text_total_shipping'] = 'משלוח';
$_['text_total_shipping_tax'] = 'מס שילוח';
$_['text_total_giftwrap'] = 'אריזת מתנה';
$_['text_total_giftwrap_tax'] = 'אריזת מתנה, מס';
$_['text_total_sub'] = 'מחיר עד עכשיו';
$_['text_tax'] = 'מס';
$_['text_total'] = 'סה״כ';

