<?php
// Text
$_['text_paid_amazon'] = 'שילמתי על אמזון';
$_['text_total_shipping'] = 'משלוחים';
$_['text_total_shipping_tax'] = 'משלוח מס';
$_['text_total_giftwrap'] = 'באריזת מתנה';
$_['text_total_giftwrap_tax'] = 'מס באריזת מתנה';
$_['text_total_sub'] = 'סך הכל תת';
$_['text_tax'] = 'מס';
$_['text_total'] = 'סה״כ';

