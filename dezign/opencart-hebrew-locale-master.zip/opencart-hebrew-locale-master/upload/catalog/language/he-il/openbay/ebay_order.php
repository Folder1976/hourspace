<?php
// Text
$_['text_total_shipping'] = 'משלוחים והובלות';
$_['text_total_discount'] = 'הנחה';
$_['text_total_tax'] = 'מס';
$_['text_total_sub'] = 'מחיר עד עכשיו';
$_['text_total'] = 'סה״כ';

