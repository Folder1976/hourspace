<?php
// Heading
$_['heading_title'] = 'מפת האתר';

// Text
$_['text_special'] = 'מבצעים מיוחדים';
$_['text_account'] = 'החשבון שלי';
$_['text_edit'] = 'פרטי חשבון';
$_['text_password'] = 'סיסמא';
$_['text_address'] = 'פנקס הכתובות';
$_['text_history'] = 'היסטוריית ההזמנות';
$_['text_download'] = 'הורדות';
$_['text_cart'] = 'עגלת קניות';
$_['text_checkout'] = 'המשך לקופה';
$_['text_search'] = 'חיפוש';
$_['text_information'] = 'מידע נוסף';
$_['text_contact'] = 'צור קשר';

