<?php
// Text
$_['text_error'] = 'דף מידע לא נמצא!';

