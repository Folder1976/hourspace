<?php
// Heading
$_['heading_title'] = 'שותפים';

// Text
$_['text_register'] = 'הרשמה';
$_['text_login'] = 'התחברות';
$_['text_logout'] = 'יציאה מהמערכת';
$_['text_forgotten'] = 'שכחת את הסיסמא';
$_['text_account'] = 'החשבון שלי';
$_['text_edit'] = 'עריכת חשבון';
$_['text_password'] = 'סיסמה';
$_['text_payment'] = 'אפשרויות תשלום';
$_['text_tracking'] = 'מעקב שותפים';
$_['text_transaction'] = 'תנועות';

