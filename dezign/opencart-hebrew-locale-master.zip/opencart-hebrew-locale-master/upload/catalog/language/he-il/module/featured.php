<?php
// Heading
$_['heading_title'] = 'בהשתתפות';

// Text
$_['text_tax'] = 'המחיר ללא מס:';

