<?php
// Heading
$_['heading_title'] = 'הנמכרים ביותר';

// Text
$_['text_tax'] = 'המחיר ללא מס:';

