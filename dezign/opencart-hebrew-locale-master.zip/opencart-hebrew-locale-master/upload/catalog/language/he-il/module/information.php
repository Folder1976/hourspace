<?php
// Heading
$_['heading_title'] = 'מידע נוסף';

// Text
$_['text_contact'] = 'צור קשר';
$_['text_sitemap'] = 'מפת האתר';

