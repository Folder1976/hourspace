<?php
// Heading
$_['heading_title'] = 'מקד את החיפוש';

