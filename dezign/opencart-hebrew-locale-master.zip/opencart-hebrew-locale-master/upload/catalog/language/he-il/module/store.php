<?php
// Heading
$_['heading_title'] = 'בחרו חנות';

// Text
$_['text_default'] = 'ברירת מחדל';
$_['text_store'] = 'נא בחרו את החנות שתרצו לבקר.';

