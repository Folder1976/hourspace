<?php
// Heading
$_['heading_title'] = 'מבצעים';

// Text
$_['text_tax'] = 'המחיר ללא מס:';

