<?php
// Heading
$_['heading_title'] = 'צ\'אט חי';

