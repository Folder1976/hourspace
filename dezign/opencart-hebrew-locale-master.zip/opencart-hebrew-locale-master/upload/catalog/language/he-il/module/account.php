<?php
// Heading
$_['heading_title'] = 'חשבון';

// Text
$_['text_register'] = 'הרשמה';
$_['text_login'] = 'כניסה';
$_['text_logout'] = 'יציאה מהמערכת';
$_['text_forgotten'] = 'שכחתי סיסמא';
$_['text_account'] = 'החשבון שלי';
$_['text_edit'] = 'עריכת חשבון';
$_['text_password'] = 'סיסמה';
$_['text_address'] = 'פנקס כתובות';
$_['text_wishlist'] = 'רשימת המשאלות';
$_['text_order'] = 'היסטוריית הזמנות';
$_['text_download'] = 'הורדות';
$_['text_reward'] = 'נקודות זיכוי';
$_['text_return'] = 'החזרות';
$_['text_transaction'] = 'תנועות';
$_['text_newsletter'] = 'רשימת תפוצה';
$_['text_recurring'] = 'תשלומים תקופתיים קבועים';

