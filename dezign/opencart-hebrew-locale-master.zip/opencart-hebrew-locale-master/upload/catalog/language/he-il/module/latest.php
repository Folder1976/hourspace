<?php
// Heading
$_['heading_title'] = 'האחרונה';

// Text
$_['text_tax'] = 'המחיר ללא מס:';

