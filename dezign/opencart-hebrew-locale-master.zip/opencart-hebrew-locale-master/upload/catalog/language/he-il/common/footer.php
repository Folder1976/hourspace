<?php
// Text
$_['text_information'] = 'מידע נוסף';
$_['text_service'] = 'שירות לקוחות';
$_['text_extra'] = 'תוספות';
$_['text_contact'] = 'צור קשר';
$_['text_return'] = 'החזרות';
$_['text_sitemap'] = 'מפת האתר';
$_['text_manufacturer'] = 'מותגים';
$_['text_voucher'] = 'שוברי מתנה';
$_['text_affiliate'] = 'שותפים';
$_['text_special'] = 'מבצעים';
$_['text_account'] = 'החשבון שלי';
$_['text_order'] = 'היסטוריית ההזמנות';
$_['text_wishlist'] = 'רשימת המבוקשים';
$_['text_newsletter'] = 'רשימת תפוצה';
$_['text_powered'] = 'מופעל על ידי <a href="http://www.opencart.com"> אופן קארט</a><br />%s&copy;%s';

