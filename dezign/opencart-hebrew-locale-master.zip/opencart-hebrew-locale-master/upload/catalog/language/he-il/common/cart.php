<?php
// Text
$_['text_items'] = '%s פריט(ים) - %s';
$_['text_empty'] = 'עגלת הקניות שלך ריקה!';
$_['text_cart'] = 'הצג עגלה';
$_['text_checkout'] = 'המשך לקופה';
$_['text_recurring'] = 'אופן התשלום';

