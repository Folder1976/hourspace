<?php
// Heading
$_['heading_title'] = 'תחזוקה';

// Text
$_['text_maintenance'] = 'תחזוקה';
$_['text_message'] = '<h1 style="text-align:center;">ברגע זה מתבצעות עבודות תחזוקה באתר.<br/>נחזור לפעילות בהקדם האפשרי.</h1>';

