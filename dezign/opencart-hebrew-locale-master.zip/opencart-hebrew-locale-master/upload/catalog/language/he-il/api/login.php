<?php
// Text
$_['text_success'] = 'הצלחה: סבב ה API החל בהצלחה !(Success: API session successfully started!)';

// Error
$_['error_login'] = 'אזהרה: אין התאמה עבור שם המשתמש והסיסמה.';

