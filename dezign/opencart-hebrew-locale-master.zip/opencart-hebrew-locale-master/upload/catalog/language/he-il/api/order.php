<?php
// Text
$_['text_success'] = 'רשימת ההזמנות שלך שונתה בהצלחה';

// Error
$_['error_permission'] = 'אזהרה: אין לך הרשאה לגשת ל- API!';
$_['error_customer'] = 'פרטי הלקוח צריכים להיות מוגדרים!';
$_['error_payment_address'] = 'כתובת התשלום הנדרש!';
$_['error_payment_method'] = 'שיטת התשלום הנדרש!';
$_['error_shipping_address'] = 'נדרשת הכתובת למשלוח!';
$_['error_shipping_method'] = 'נדרשת שיטת ביצוע המשלוח!';
$_['error_stock'] = 'המוצרים מסומנים * * * אינם זמינים בכמות הרצויה או לא זמינים במלאי!';
$_['error_minimum'] = 'סכום ההזמנה המינימלית עבור %s הוא %s!';
$_['error_not_found'] = 'אזהרה: לא ניתן למצוא את ההזמנה!';

