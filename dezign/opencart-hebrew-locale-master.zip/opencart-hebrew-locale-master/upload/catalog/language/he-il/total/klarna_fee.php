<?php
$_['text_klarna_fee'] = 'דמי Klarna';

