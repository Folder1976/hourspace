<?php
$_['text_sub_total'] = 'סך מחיר פריטים';

