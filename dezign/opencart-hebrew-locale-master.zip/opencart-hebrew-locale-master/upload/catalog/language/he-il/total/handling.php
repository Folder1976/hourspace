<?php
$_['text_handling'] = 'דמי טיפול';

