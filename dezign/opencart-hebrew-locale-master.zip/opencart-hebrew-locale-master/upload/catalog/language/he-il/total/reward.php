<?php
// Text
$_['text_reward'] = 'נקודות זיכוי (%s)';
$_['text_order_id'] = 'מזהה הזמנה: #%s';

