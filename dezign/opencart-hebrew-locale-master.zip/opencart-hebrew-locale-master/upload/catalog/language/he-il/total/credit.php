<?php
$_['text_credit'] = 'אשראי בחנות';
$_['text_order_id'] = 'מזהה הזמנה: #%s';

