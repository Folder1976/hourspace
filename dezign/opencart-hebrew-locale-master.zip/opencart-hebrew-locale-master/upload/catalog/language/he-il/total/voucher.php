<?php
// Text
$_['text_voucher'] = 'שובר (%s)';

