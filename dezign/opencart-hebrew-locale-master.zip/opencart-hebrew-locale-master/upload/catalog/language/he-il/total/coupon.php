<?php
// Text
$_['text_coupon'] = 'קופון (%s)';

