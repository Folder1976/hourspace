<?php
$_['text_total'] = 'סה"כ';

