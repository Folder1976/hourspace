<?php
// Text
$_['text_title'] = 'פדקס';
$_['text_weight'] = 'משקל:';
$_['text_eta'] = 'זמן משוער:';
$_['text_europe_first_international_priority'] = 'עדיפות בינלאומית ראשונה באירופה';
$_['text_fedex_1_day_freight'] = 'Fedex Freight 1 יום';
$_['text_fedex_2_day'] = 'פדקס 2 יום';
$_['text_fedex_2_day_am'] = 'פדקס AM יום 2';
$_['text_fedex_2_day_freight'] = '2 יום פדקס משלוחי שכר';
$_['text_fedex_3_day_freight'] = 'פדקס שכר - שלושה ימים';
$_['text_fedex_express_saver'] = 'פדקס אקספרס - חסכון';
$_['text_fedex_first_freight'] = 'פדקס שכר ראשון';
$_['text_fedex_freight_economy'] = 'פדקס - שכר - אקונומי';
$_['text_fedex_freight_priority'] = 'פדקס שכר - עדיפות';
$_['text_fedex_ground'] = 'פדקס - קרקעי';
$_['text_first_overnight'] = 'פדקס בין לילה';
$_['text_ground_home_delivery'] = 'משלוח רכוב הביתה';
$_['text_international_economy'] = 'משלוח אקונומי בינ״ל';
$_['text_international_economy_freight'] = 'משלוח שכר בינלואמי';
$_['text_international_first'] = 'משלוח בינלאומי - ראשון';
$_['text_international_priority'] = 'משלוח בינלאומי עדיפות';
$_['text_international_priority_freight'] = 'בינלאומי עדיפות שכר';
$_['text_priority_overnight'] = 'עדיפות משלוח 24 שעות';
$_['text_smart_post'] = 'משלוח חכם';
$_['text_standard_overnight'] = 'משלוח סטנדרטי 24 שעות';

