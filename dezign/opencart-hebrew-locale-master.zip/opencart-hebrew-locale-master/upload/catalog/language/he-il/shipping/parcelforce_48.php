<?php
// Text
$_['text_title'] = 'Parcelforce 48';
$_['text_description'] = 'Parcelforce 48';
$_['text_weight'] = 'משקל:';
$_['text_insurance'] = 'ביטוח עד ל:';
$_['text_time'] = 'זמן משוער: תוך 48 שעות';

