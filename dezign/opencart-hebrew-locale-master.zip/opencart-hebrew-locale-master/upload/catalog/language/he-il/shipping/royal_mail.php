<?php
// Text
$_['text_title'] = 'הדואר המלכותי הבריטי';
$_['text_weight'] = 'משקל:';
$_['text_insurance'] = 'ביטוח עד ל:';
$_['text_1st_class_standard'] = 'פוסט רגיל מחלקה ראשונה';
$_['text_1st_class_recorded'] = 'מחלקה ראשונה דואר רשום';
$_['text_2nd_class_standard'] = 'פוסט סטנדרטי סוג ב\'';
$_['text_2nd_class_recorded'] = 'סוג ב\' דואר רשום';
$_['text_special_delivery_500'] = 'משלוח מיוחד ביום למחרת (£500)';
$_['text_special_delivery_1000'] = 'משלוח מיוחד ביום למחרת (£500)';
$_['text_special_delivery_2500'] = 'משלוח מיוחד ביום למחרת (£500)';
$_['text_standard_parcels'] = 'חבילות רגיל';
$_['text_airmail'] = 'דואר אוויר';
$_['text_international_signed'] = 'בינלאומי חתום';
$_['text_airsure'] = 'Airsure';
$_['text_surface'] = 'משטח';

