<?php
// Text
$_['text_title'] = 'איסוף';
$_['text_description'] = 'איסוף מהחנות';

