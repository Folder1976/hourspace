<?php
// Text
$_['text_title'] = 'משלוח מבוסס משקל';
$_['text_weight'] = 'משקל:';

