<?php
// Text
$_['text_title'] = 'דואר אוסטרליה';
$_['text_express'] = 'אקספרס';
$_['text_standard'] = 'משלוח רגיל';
$_['text_eta'] = 'ימים';

