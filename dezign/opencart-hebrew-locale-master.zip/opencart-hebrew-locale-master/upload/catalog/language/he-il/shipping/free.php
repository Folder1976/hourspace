<?php
// Text
$_['text_title'] = 'משלוח חינם';
$_['text_description'] = 'משלוח חינם';

