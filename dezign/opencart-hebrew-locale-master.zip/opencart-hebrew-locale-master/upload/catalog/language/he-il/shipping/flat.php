<?php
// Text
$_['text_title'] = 'תעריף קבוע';
$_['text_description'] = 'תעריף משלוח קבוע';

