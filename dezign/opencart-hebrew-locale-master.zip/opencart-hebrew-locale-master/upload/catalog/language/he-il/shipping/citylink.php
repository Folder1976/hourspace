<?php
// Text
$_['text_title'] = 'סיטילינק';
$_['text_weight'] = 'משקל:';

