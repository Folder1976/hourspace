<?php
// Text
$_['text_title'] = 'לפריט';
$_['text_description'] = 'מחיר משלוח לפי מוצר';

