<?php
// Text
$_['text_subject'] = '%s - סיסמה חדשה';
$_['text_greeting'] = 'סיסמה חדשה נדרש מן %s.';
$_['text_password'] = 'הסיסמה החדשה שלך היא:';

