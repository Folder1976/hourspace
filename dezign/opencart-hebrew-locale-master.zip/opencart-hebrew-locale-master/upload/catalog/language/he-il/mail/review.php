<?php
// Text
$_['text_subject'] = '%s - סקירת מוצר';
$_['text_waiting'] = 'יש לך מוצר חדש לסקור את ההמתנה.';
$_['text_product'] = 'המוצר: %s';
$_['text_reviewer'] = 'הבודק: %s';
$_['text_rating'] = 'דירוג: %s';
$_['text_review'] = 'סקור את הטקסט:';

