<?php
// Heading
$_['heading_title'] = 'חשבון השותף שלי';

// Text
$_['text_account'] = 'חשבון';
$_['text_my_account'] = 'חשבון השותף שלי';
$_['text_my_tracking'] = 'My Tracking Information';
$_['text_my_transactions'] = 'העסקאות שלך';
$_['text_edit'] = 'ערוך את פרטי החשבון שלך';
$_['text_password'] = 'שנה את הסיסמה שלך';
$_['text_payment'] = 'שנה את ההעדפות התשלום שלך';
$_['text_tracking'] = 'שותפים מותאם אישית קוד מעקב';
$_['text_transaction'] = 'הצג את היסטוריית עסקאות שלך';

