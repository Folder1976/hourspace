<?php
// Heading
$_['heading_title'] = 'התנתקות מהחשבון';

// Text
$_['text_message'] = '<p>You have been logged off your Affiliate Account.</p>';
$_['text_account'] = 'חשבון';
$_['text_logout'] = 'התנתק';

