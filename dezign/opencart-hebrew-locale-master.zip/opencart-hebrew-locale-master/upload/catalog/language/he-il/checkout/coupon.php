<?php
// Heading
$_['heading_title'] = 'קוד קופון';

// Text
$_['text_success'] = 'הצלחה: הנחה קופון שלך הוחל!';

// Entry
$_['entry_coupon'] = 'הזן את הקופון שלך כאן';

// Error
$_['error_coupon'] = 'אזהרה: קופון אינו חוקי, פג או הגיע למגבלה שלו עבור השימוש!';
$_['error_empty'] = 'אזהרה: נא להזין קוד קופון!';

