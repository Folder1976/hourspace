<?php
// Heading
$_['heading_title'] = 'החשבון שלי';

// Text
$_['text_account'] = 'חשבון';
$_['text_my_account'] = 'החשבון שלי';
$_['text_my_orders'] = 'הזמנות שלי';
$_['text_my_newsletter'] = 'רשימת תפוצה';
$_['text_edit'] = 'ערוך את פרטי החשבון שלך';
$_['text_password'] = 'לשנות את הסיסמה שלך';
$_['text_address'] = 'לשנות את ערכי פנקס כתובות';
$_['text_wishlist'] = 'לשנות את רשימת המשאלות שלך';
$_['text_order'] = 'הצג את היסטוריית ההזמנות שלך';
$_['text_download'] = 'הורדות';
$_['text_reward'] = 'נקודות התגמול שלך';
$_['text_return'] = 'הצג בקשות החזרה';
$_['text_transaction'] = 'העסקאות שלך';
$_['text_newsletter'] = 'הרשמה / הסרת הרשמה לניוזלטר';
$_['text_recurring'] = 'תשלומים תקופתיים קבועים';
$_['text_transactions'] = 'תשלומים';

