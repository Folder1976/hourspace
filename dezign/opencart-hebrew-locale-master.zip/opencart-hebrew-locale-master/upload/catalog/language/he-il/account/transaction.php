<?php
// Heading
$_['heading_title'] = 'העסקאות שלך';

// Column
$_['column_date_added'] = 'תאריך הוספה';
$_['column_description'] = 'תיאור';
$_['column_amount'] = 'כמות (%s)';

// Text
$_['text_account'] = 'חשבון';
$_['text_transaction'] = 'העסקאות שלך';
$_['text_total'] = 'מאזן היתרה הנוכחי שלך הוא:';
$_['text_empty'] = 'אין לך עסקאות רשומות במערכת!';

