<?php
// Heading
$_['heading_title'] = 'הרשמה לרשימת תפוצה';

// Text
$_['text_account'] = 'חשבון';
$_['text_newsletter'] = 'רשימת תפוצה';
$_['text_success'] = 'הצלחה: הרשמתך לרשימת התפוצה עודכנה!';

// Entry
$_['entry_newsletter'] = 'הירשם';

