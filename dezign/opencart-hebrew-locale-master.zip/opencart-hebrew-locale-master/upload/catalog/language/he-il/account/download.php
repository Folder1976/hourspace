<?php
// Heading
$_['heading_title'] = 'חשבון הורדות';

// Text
$_['text_account'] = 'חשבון';
$_['text_downloads'] = 'הורדות';
$_['text_empty'] = 'אתה לא הפכת כלשהו ההזמנות הקודמות להורדה!';

// Column
$_['column_order_id'] = 'מספר הזמנה';
$_['column_name'] = 'שם';
$_['column_size'] = 'גודל';
$_['column_date_added'] = 'תאריך הוספה';

