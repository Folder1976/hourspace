<?php
// Heading
$_['heading_title'] = 'נקודות התגמול שלך';

// Column
$_['column_date_added'] = 'תאריך ההזמנה';
$_['column_description'] = 'תיאור';
$_['column_points'] = 'נקודות';

// Text
$_['text_account'] = 'חשבון';
$_['text_reward'] = 'נקודות זיכוי';
$_['text_total'] = 'את המספר הכולל של נקודות מצטברות הוא:';
$_['text_empty'] = 'אין לך כל נקודות גמול!';

