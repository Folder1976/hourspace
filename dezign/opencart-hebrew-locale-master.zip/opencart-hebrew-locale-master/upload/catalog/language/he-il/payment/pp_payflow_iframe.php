<?php
// Text
$_['text_title'] = 'אשראי או כרטיס חיוב';
$_['text_secure_connection'] = 'יצירת חיבור מאובטח...';

// Error
$_['error_connection'] = 'לא היתה אפשרות להתחבר ל- PayPal. נא פנה אל מנהל החנות לקבלת סיוע או בחר שיטת תשלום אחרת.';

