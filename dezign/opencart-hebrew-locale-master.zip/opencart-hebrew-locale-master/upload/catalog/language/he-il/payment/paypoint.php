<?php
// Heading
$_['heading_title'] = 'תודה על קניות עם %s.... ';

// Text
$_['text_title'] = 'כרטיס אשראי / כרטיס חיוב (PayPoint)';
$_['text_response'] = 'התגובה של PayPoint:';
$_['text_success'] = '... התשלום התקבל בהצלחה.';
$_['text_success_wait'] = '<b><span style="color: #FF0000"> אנא המתן...</span></b> בעוד אנחנו לסיים את עיבוד הזמנתך. <br>אם אתה לא באופן אוטומטי מחדש מופנה תוך 10 שניות, בבקשה לחץ <a href="%s"> כאן</a>.';
$_['text_failure'] = '... התשלום שלך בוטל!';
$_['text_failure_wait'] = '<b><span style="color: #FF0000"> אנא המתן...</span></b> <br>אם אתה לא באופן אוטומטי מחדש מופנה תוך 10 שניות, בבקשה לחץ <a href="%s"> כאן</a>.';

