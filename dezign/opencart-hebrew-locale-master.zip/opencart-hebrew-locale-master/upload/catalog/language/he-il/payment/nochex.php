<?php
// Text
$_['text_title'] = 'כרטיס אשראי / כרטיס חיוב (NOCHEX)';

