<?php
// Text
$_['text_title'] = 'כרטיס אשראי';

