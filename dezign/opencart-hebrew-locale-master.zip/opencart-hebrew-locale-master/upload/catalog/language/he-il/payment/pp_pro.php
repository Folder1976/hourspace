<?php
// Text
$_['text_title'] = 'אשראי או כרטיס חיוב (מעובד באופן מאובטח באמצעות פיי פאל)';
$_['text_wait'] = 'אנא המתן!';
$_['text_credit_card'] = 'פרטי כרטיס האשראי';
$_['text_loading'] = 'טוען';

// Entry
$_['entry_cc_type'] = 'סוג הכרטיס';
$_['entry_cc_number'] = 'מספר כרטיס';
$_['entry_cc_start_date'] = 'כרטיס בתוקף מתאריך';
$_['entry_cc_expire_date'] = 'תאריך תפוגת הכרטיס';
$_['entry_cc_cvv2'] = 'שלוש ספרות אחרונות מאחורי הכרטיס (לאבטחה)';
$_['entry_cc_issue'] = 'מספר הכרטיס';

// Help
$_['help_start_date'] = '(אם זמין)';
$_['help_issue'] = '(עבור מאסטרו סולו וכרטיסי בלבד)';

