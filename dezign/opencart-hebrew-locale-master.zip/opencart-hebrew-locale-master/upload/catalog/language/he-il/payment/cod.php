<?php
// Text
$_['text_title'] = 'תשלום במזומן';

