<?php
// Text
$_['text_title'] = 'משלוח חינם';

