<?php
// Text
$_['text_upload'] = 'הקובץ הועלה בהצלחה!';

// Error
$_['error_filename'] = 'שם הקובץ חייב להיות בין 3 ל 64 תווים!';
$_['error_filetype'] = 'סוג קובץ לא חוקי!';
$_['error_upload'] = 'נדרשת העלאת קובץ!';

