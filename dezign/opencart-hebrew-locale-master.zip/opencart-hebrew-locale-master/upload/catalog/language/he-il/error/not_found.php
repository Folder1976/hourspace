<?php
// Heading
$_['heading_title'] = 'הדף שביקשת לא נמצא!';

// Text
$_['text_error'] = 'הדף שביקשת לא נמצא.';

