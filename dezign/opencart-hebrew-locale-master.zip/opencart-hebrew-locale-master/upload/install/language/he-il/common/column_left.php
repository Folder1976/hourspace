<?php
$_['text_license'] = 'רשיון';
$_['text_installation'] = 'לפני התקנה';
$_['text_configuration'] = 'קונפיגורציה';
$_['text_upgrade'] = 'שידרוג';
$_['text_finished'] = 'הסתיים';
$_['text_language'] = 'שפה';
