<?php
// Heading
$_['heading_title'] = 'מצגת';

// Text
$_['text_module'] = 'מודולים';
$_['text_success'] = 'הצלחה: שינוי מודול מצגת!';
$_['text_edit'] = 'עריכת מצגת מודול';

// Entry
$_['entry_banner'] = 'באנר';
$_['entry_dimension'] = 'ממד (W x H), שינוי גודל כתב';
$_['entry_width'] = 'רוחב';
$_['entry_height'] = 'גובה';
$_['entry_status'] = 'סטטוס';

// Error
$_['error_permission'] = 'אזהרה: אין לך הרשאה לשינוי מודול מצגת!';
$_['error_module'] = 'אזהרה: מודול חובה!';
$_['error_dimension'] = 'מידות גובה ורוחב נדרשות!';

