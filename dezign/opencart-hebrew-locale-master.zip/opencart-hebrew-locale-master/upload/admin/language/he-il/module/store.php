<?php
// Heading
$_['heading_title'] = 'חנות';

// Text
$_['text_module'] = 'מודולים';
$_['text_success'] = 'הצלחה: שינוי מודול החנות!';
$_['text_edit'] = 'מודול החנות עריכה';

// Entry
$_['entry_admin'] = 'משתמשים עם הרשאת אדמיניסטרציה בלבד';
$_['entry_status'] = 'סטטוס';

// Error
$_['error_permission'] = 'אזהרה: אין לך הרשאה לשינוי מודול חשבון!';

