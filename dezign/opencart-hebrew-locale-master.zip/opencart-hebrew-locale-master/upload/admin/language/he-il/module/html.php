<?php
// Heading
$_['heading_title'] = 'תוכן HTML';

// Text
$_['text_module'] = 'מודולים';
$_['text_success'] = 'הצלחה: שינוי תוכן HTML מודול!';
$_['text_edit'] = 'עריכת תוכן HTML מודול';

// Entry
$_['entry_heading'] = 'כותרת כותרת';
$_['entry_description'] = 'תוכן';
$_['entry_status'] = 'סטטוס';

// Error
$_['error_permission'] = 'אזהרה: אין לך הרשאה לשנות את תוכן HTML מודול!';
$_['error_module'] = 'אזהרה: מודול נדרש!';

