<?php
// Heading
$_['heading_title'] = 'חשבון';
$_['text_module'] = 'מודולים';
$_['text_success'] = 'הצלחה: שינוי מודול חשבון!';
$_['text_edit'] = 'עריכת חשבון מודול';

// Entry
$_['entry_status'] = 'סטטוס';

// Error
$_['error_permission'] = 'אזהרה: אין לך הרשאה לשינוי מודול חשבון!';

