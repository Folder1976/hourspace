<?php
// Heading
$_['heading_title'] = 'הנמכרים ביותר';

// Text
$_['text_module'] = 'מודולים';
$_['text_success'] = 'הצלחה: שינוי מודול הנמכרים ביותר!';
$_['text_edit'] = 'עריכת מודול הנמכרים ביותר';

// Entry
$_['entry_limit'] = 'מגבלה';
$_['entry_image'] = 'התמונה (W x H), שינוי גודל כתב';
$_['entry_width'] = 'רוחב';
$_['entry_height'] = 'גובה';
$_['entry_status'] = 'סטטוס';

// Error
$_['error_permission'] = 'אזהרה: אין לך הרשאה לשינוי מודול הנמכרים ביותר!';
$_['error_module'] = 'אזהרה: מודול נדרש!';
$_['error_image'] = 'רוחב גובה &amp; מידות התמונה הנדרשות!';

