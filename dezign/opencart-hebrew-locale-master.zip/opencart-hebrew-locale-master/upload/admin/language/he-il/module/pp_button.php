<?php
// Heading
$_['heading_title'] = 'לחצן הוצאה PayPal אקספרס';

// Text
$_['text_module'] = 'מודולים';
$_['text_success'] = 'הצלחה: שינוי מודול PayPal אקספרס לחצן הוצאה!';
$_['text_edit'] = 'עריכת מודול לחצן הוצאה PayPal אקספרס';

// Entry
$_['entry_status'] = 'סטטוס';

// Error
$_['error_permission'] = 'אזהרה: אין לך הרשאה לשינוי מודול PayPal אקספרס לחצן הוצאה!';

