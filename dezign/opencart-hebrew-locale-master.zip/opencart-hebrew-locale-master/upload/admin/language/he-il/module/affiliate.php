<?php
// Heading
$_['heading_title'] = 'שותפים';
$_['text_module'] = 'מודולים';
$_['text_success'] = 'הצלחה: שינוי מודול שותפים!';
$_['text_edit'] = 'עריכת מודול שותפים';

// Entry
$_['entry_status'] = 'סטטוס';

// Error
$_['error_permission'] = 'אזהרה: אין לך הרשאה לשינוי מודול שותפים!';

