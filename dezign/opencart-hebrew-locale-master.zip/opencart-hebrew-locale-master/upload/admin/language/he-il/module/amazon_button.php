<?php
// Heading
$_['heading_title'] = 'כפתור תשלומים אמזון';
$_['text_module'] = 'מודולים';
$_['text_success'] = 'הצלחה: שינוי מודול תשלומים אמזון!';
$_['text_edit'] = 'עריכת אמזון תשלומים מודול';

// Entry
$_['entry_status'] = 'סטטוס';

// Error
$_['error_permission'] = 'אזהרה: אין לך הרשאה לשינוי מודול תשלומים אמזון!';

