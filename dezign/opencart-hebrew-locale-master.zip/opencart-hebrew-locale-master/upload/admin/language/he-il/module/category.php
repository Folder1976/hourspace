<?php
// Heading
$_['heading_title'] = 'קטגוריה';

// Text
$_['text_module'] = 'מודולים';
$_['text_success'] = 'הצלחה: שינוי קטגוריה במודול!';
$_['text_edit'] = 'עריכת קטגוריה מודול';

// Entry
$_['entry_status'] = 'סטטוס';

// Error
$_['error_permission'] = 'אזהרה: אין לך הרשאה לשינוי מודול חשבון!';

