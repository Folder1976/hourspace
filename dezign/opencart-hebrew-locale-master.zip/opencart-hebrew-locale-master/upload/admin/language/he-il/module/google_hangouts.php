<?php
// Heading
$_['heading_title'] = 'גוגל מקומות הבילוי';

// Text
$_['text_module'] = 'מודולים';
$_['text_success'] = 'הצלחה: שינוי גוגל מקומות הבילוי מודול!';
$_['text_edit'] = 'עריכה גוגל מקומות הבילוי מודול';

// Entry
$_['entry_code'] = 'Google Talk קוד';
$_['entry_status'] = 'סטטוס';

// Help
$_['help_code'] = 'Goto <a href="https://developers.google.com/+/hangouts/button" target="_blank"> צור תג chatback מפגש של גוגל</a>, העתק והדבק הקוד שנוצר לתוך תיבת הטקסט.';

// Error
$_['error_permission'] = 'אזהרה: אין לך הרשאה לשינוי גוגל מקומות הבילוי מודול!';
$_['error_code'] = 'הקוד הנדרש';

