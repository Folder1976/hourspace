<?php
// Heading
$_['heading_title'] = 'מידע נוסף';

// Text
$_['text_module'] = 'מודולים';
$_['text_success'] = 'הצלחה: שינוי מידע מודול!';
$_['text_edit'] = 'עריכת מידע מודול';

// Entry
$_['entry_status'] = 'סטטוס';

// Error
$_['error_permission'] = 'אזהרה: אין לך הרשאה לשינוי מודול מידע!';

