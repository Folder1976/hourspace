<?php
// Heading
$_['heading_title'] = 'סנן';

// Text
$_['text_module'] = 'מודולים';
$_['text_success'] = 'הצלחה: שינוי מודול הבאנר!';
$_['text_edit'] = 'עריכת מסנן מודול';

// Entry
$_['entry_status'] = 'סטטוס';

// Error
$_['error_permission'] = 'אזהרה: אין לך הרשאה לשינוי מודול חשבון!';

