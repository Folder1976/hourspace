<?php
// Heading
$_['heading_title'] = 'אחרונים';

// Text
$_['text_module'] = 'מודולים';
$_['text_success'] = 'הצלחה: שינוי מודול אחרונים!';
$_['text_edit'] = 'עריכת מודול האחרונים';

// Entry
$_['entry_limit'] = 'מגבלה';
$_['entry_image'] = 'התמונה (W x H), שינוי גודל כתב';
$_['entry_width'] = 'רוחב';
$_['entry_height'] = 'גובה';
$_['entry_status'] = 'סטטוס';

// Error
$_['error_permission'] = 'אזהרה: אין לך הרשאה לשינוי מודול האחרונים!';
$_['error_module'] = 'אזהרה: מודול נדרש!';
$_['error_image'] = 'רוחב גובה &amp; מידות התמונה הנדרשות!';

