<?php
// Heading
$_['heading_title'] = 'קרוסלה';

// Text
$_['text_module'] = 'מודולים';
$_['text_success'] = 'הצלחה: שינוי מודול קרוסלה!';
$_['text_edit'] = 'עריכת מודול קרוסלה';

// Entry
$_['entry_banner'] = 'באנר';
$_['entry_limit'] = 'מגבלה';
$_['entry_scroll'] = 'גלילה';
$_['entry_image'] = 'התמונה (W x H), שינוי גודל כתב';
$_['entry_width'] = 'רוחב';
$_['entry_height'] = 'גובה';
$_['entry_status'] = 'סטטוס';

// Error
$_['error_permission'] = 'אזהרה: אין לך הרשאה לשינוי מודול חשבון!';
$_['error_module'] = 'אזהרה: מודול נדרש!';
$_['error_image'] = 'רוחב גובה &amp; מידות התמונה הנדרשות!';

