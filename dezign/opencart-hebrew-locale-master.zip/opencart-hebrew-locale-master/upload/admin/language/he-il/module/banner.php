<?php
// Heading
$_['heading_title'] = 'באנר';

// Text
$_['text_module'] = 'מודולים';
$_['text_success'] = 'הצלחה: שינוי מודול הבאנר!';
$_['text_edit'] = 'עריכת באנר המודול';

// Entry
$_['entry_banner'] = 'באנר';
$_['entry_dimension'] = 'ממד (W x H), שינוי גודל כתב';
$_['entry_width'] = 'רוחב';
$_['entry_height'] = 'גובה';
$_['entry_status'] = 'סטטוס';

// Error
$_['error_permission'] = 'אזהרה: אין לך הרשאה לשינוי מודול חשבון!';
$_['error_module'] = 'אזהרה: מודול חובה!';
$_['error_dimension'] = 'מידות גובה ורוחב נדרשות!';

