<?php
// Heading
$_['heading_title'] = 'תעריף קבוע';

// Text
$_['text_shipping'] = 'משלוחים';
$_['text_success'] = 'הצלחה: שינוי תעריף משלוח!';
$_['text_edit'] = 'עריכת תעריף משלוח';

// Entry
$_['entry_cost'] = 'עלות';
$_['entry_tax_class'] = 'שיעור המס';
$_['entry_geo_zone'] = 'אזור גיאוגרפי';
$_['entry_status'] = 'סטטוס';
$_['entry_sort_order'] = 'סדר';

// Error
$_['error_permission'] = 'אזהרה: אין לך הרשאה לשינוי משלוחים!';

