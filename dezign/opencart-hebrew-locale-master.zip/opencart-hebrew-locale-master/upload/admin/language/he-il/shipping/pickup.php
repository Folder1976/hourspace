<?php
// Heading
$_['heading_title'] = 'איסוף מהחנות';

// Text
$_['text_shipping'] = 'משלוחים והובלות';
$_['text_success'] = 'הצלחה: שינוי האיסוף מהחנות!';
$_['text_edit'] = 'עריכת איסוף המשלוח חנות';

// Entry
$_['entry_geo_zone'] = 'אזור גיאוגרפי';
$_['entry_status'] = 'סטטוס';
$_['entry_sort_order'] = 'מיין לפי';

// Error
$_['error_permission'] = 'אזהרה: אין לך הרשאה לשינוי האיסוף מהחנות!';

