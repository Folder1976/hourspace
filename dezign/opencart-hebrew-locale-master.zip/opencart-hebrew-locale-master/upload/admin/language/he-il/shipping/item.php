<?php
// Heading
$_['heading_title'] = 'לפריט';

// Text
$_['text_shipping'] = 'משלוחים והובלות';
$_['text_success'] = 'הצלחה: שינוי משלוח לכל פריט המחירים!';
$_['text_edit'] = 'ערוך משלוח לפי פריט';

// Entry
$_['entry_cost'] = 'עלות';
$_['entry_tax_class'] = 'שיעור המס';
$_['entry_geo_zone'] = 'אזור גיאוגרפי';
$_['entry_status'] = 'סטטוס';
$_['entry_sort_order'] = 'מיין לפי';

// Error
$_['error_permission'] = 'אזהרה: אין לך הרשאה לשינוי משלוח לכל פריט המחירים!';

