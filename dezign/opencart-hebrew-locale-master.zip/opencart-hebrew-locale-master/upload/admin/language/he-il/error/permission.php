<?php
// Heading
$_['heading_title'] = 'הגישה נדחתה!';

// Text
$_['text_permission'] = 'אין לך הרשאה לגשת לדף זה, נא לפנות למנהל המערכת.';

