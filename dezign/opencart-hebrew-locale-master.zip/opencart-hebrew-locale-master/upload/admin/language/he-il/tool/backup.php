<?php
// Heading
$_['heading_title'] = 'גיבוי &amp; שחזור';

// Text
$_['text_backup'] = ' הורדות גיבוי';
$_['text_success'] = 'הצלחה: בהצלחה ייבאת את מסד הנתונים שלך!';
$_['text_list'] = 'להעלות רשימה';

// Entry
$_['entry_restore'] = 'שחזר גיבוי';
$_['entry_backup'] = 'גבה';

// Error
$_['error_permission'] = 'אזהרה: אין לך הרשאה לשינוי גיבויים!';
$_['error_backup'] = 'אזהרה: עליך לבחור טבלה אחת לפחות לגבות!';
$_['error_empty'] = 'אזהרה: הקובץ שנטען היה ריק!';

