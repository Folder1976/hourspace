<?php
// Heading
$_['heading_title'] = 'העלאות';

// Text
$_['text_success'] = 'הצלחה: שינוי העלאות!';
$_['text_list'] = 'רשימת העלאות';

// Column
$_['column_name'] = 'שם העלאה';
$_['column_filename'] = 'שם הקובץ';
$_['column_date_added'] = 'תאריך ההוספה';
$_['column_action'] = 'פעולה';

// Entry
$_['entry_name'] = 'שם העלאה';
$_['entry_filename'] = 'שם הקובץ';
$_['entry_date_added'] = 'תאריך ההזמנה';

// Error
$_['error_permission'] = 'אזהרה: אין לך הרשאה לשינוי העלאות!';

