<?php
// Heading
$_['heading_title'] = 'OpenBay Pro';

// Text
$_['text_module'] = 'מודולים';
$_['text_installed'] = 'מודול OpenBay Pro מותקן כעת. זה זמין תחת סיומות-> OpenBay Pro';

