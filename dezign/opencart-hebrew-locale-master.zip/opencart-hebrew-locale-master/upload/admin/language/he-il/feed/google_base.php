<?php
// Heading
$_['heading_title'] = 'Google Base';

// Text
$_['text_feed'] = 'פידים';
$_['text_success'] = 'הצלחה: שינוי בסיס Google הזנה!';
$_['text_list'] = 'רשימת אופני תצוגה';

// Entry
$_['entry_status'] = 'סטטוס';
$_['entry_data_feed'] = 'כתובת url של הזנת נתונים';

// Error
$_['error_permission'] = 'אזהרה: אין לך הרשאה לשינוי בסיס Google הזנה!';

