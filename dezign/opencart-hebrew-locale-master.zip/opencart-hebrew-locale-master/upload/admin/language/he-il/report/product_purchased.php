<?php
// Heading
$_['heading_title'] = 'דו"ח מוצרים שנרכשו';

// Text
$_['text_list'] = 'רשימת מוצרים שנרכשו';
$_['text_all_status'] = 'כל מצבי ההזמנות';

// Column
$_['column_date_start'] = 'תאריך התחלה';
$_['column_date_end'] = 'תאריך סיום';
$_['column_name'] = 'שם המוצר';
$_['column_model'] = 'דגם';
$_['column_quantity'] = 'כמות';
$_['column_total'] = 'סה״כ';

// Entry
$_['entry_date_start'] = 'תאריך התחלה';
$_['entry_date_end'] = 'תאריך סיום';
$_['entry_status'] = 'מצב ההזמנה';

