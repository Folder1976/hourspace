<?php
// Heading
$_['heading_title'] = 'דו״ח לקוחות מחוברים';

// Text
$_['text_list'] = 'רשימת לקוחות מחוברים';
$_['text_guest'] = 'אורח';

// Column
$_['column_ip'] = 'כתובת IP';
$_['column_customer'] = 'לקוח';
$_['column_url'] = 'הדף האחרון ביקר';
$_['column_referer'] = 'מפנה';
$_['column_date_added'] = 'לחיצה אחרונה';
$_['column_action'] = 'פעולה';

// Entry
$_['entry_ip'] = 'כתובת IP';
$_['entry_customer'] = 'לקוח';

