<?php
// Heading
$_['heading_title'] = 'דו״ח הזמנות לקוח';

// Text
$_['text_list'] = 'רשימת הזמנות לקוח';
$_['text_all_status'] = 'כל מצבי ההזמנות';

// Column
$_['column_customer'] = 'שם הלקוח';
$_['column_email'] = 'דואר אלקטרוני';
$_['column_customer_group'] = 'קבוצות לקוח';
$_['column_status'] = 'סטטוס';
$_['column_orders'] = 'מספר הזמנות';
$_['column_products'] = 'מספר מוצרים';
$_['column_total'] = 'סה״כ';
$_['column_action'] = 'פעולה';

// Entry
$_['entry_date_start'] = 'תאריך התחלה';
$_['entry_date_end'] = 'תאריך סיום';
$_['entry_status'] = 'מצב ההזמנה';

