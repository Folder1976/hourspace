<?php
// Heading
$_['heading_title'] = 'דו״ח עמלת שותפים';

// Text
$_['text_list'] = 'רשימת עמלת שותפים';

// Column
$_['column_affiliate'] = 'שם השותף';
$_['column_email'] = 'דואר אלקטרוני';
$_['column_status'] = 'סטטוס';
$_['column_commission'] = 'עמלה';
$_['column_orders'] = 'מספר הזמנות';
$_['column_total'] = 'סה״כ';
$_['column_action'] = 'פעולה';

// Entry
$_['entry_date_start'] = 'תאריך התחלה';
$_['entry_date_end'] = 'תאריך סיום';

