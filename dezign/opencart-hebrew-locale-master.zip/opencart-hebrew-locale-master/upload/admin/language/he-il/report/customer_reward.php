<?php
// Heading
$_['heading_title'] = 'דו״ח נקודות גמול לקוח';

// Text
$_['text_list'] = 'רשימת נקודות גמול ללקוח';

// Column
$_['column_customer'] = 'שם הלקוח';
$_['column_email'] = 'דואר אלקטרוני';
$_['column_customer_group'] = 'קבוצות לקוח';
$_['column_status'] = 'סטטוס';
$_['column_points'] = 'נקודות גמול (זיכוי)';
$_['column_orders'] = 'מספר הזמנות';
$_['column_total'] = 'סה״כ';
$_['column_action'] = 'פעולה';

// Entry
$_['entry_date_start'] = 'תאריך התחלה';
$_['entry_date_end'] = 'תאריך סיום';

