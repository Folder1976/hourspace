<?php
// Heading
$_['heading_title'] = 'דו״ח שיווק';

// Text
$_['text_list'] = 'רשימת שיווק';
$_['text_all_status'] = 'כל מצבי ההזמנות';

// Column
$_['column_campaign'] = 'שם הקמפיין';
$_['column_code'] = 'קוד';
$_['column_clicks'] = 'קליקים';
$_['column_orders'] = 'מספר הזמנות';
$_['column_total'] = 'סה״כ';

// Entry
$_['entry_date_start'] = 'תאריך התחלה';
$_['entry_date_end'] = 'תאריך סיום';
$_['entry_status'] = 'מצב ההזמנה';

