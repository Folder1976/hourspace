<?php
// Heading
$_['heading_title'] = 'דו"ח מוצרים שנצפו';

// Text
$_['text_list'] = 'רשימת מוצרים שנצפו';
$_['text_success'] = 'הצלחה: איפסת את הדוח המוצרים שנצפו!';

// Column
$_['column_name'] = 'שם המוצר';
$_['column_model'] = 'דגם';
$_['column_viewed'] = 'מס. צפיות';
$_['column_percent'] = 'אחוז';

// Error
$_['error_permission'] = 'אזהרה: אין לך הרשאה לאפס המוצר דו"ח מוצרים שנצפו!';

