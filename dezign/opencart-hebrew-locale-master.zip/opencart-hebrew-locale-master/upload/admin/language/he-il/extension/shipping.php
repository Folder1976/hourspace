<?php
// Heading
$_['heading_title'] = 'משלוחים והובלות';

// Text
$_['text_success'] = 'הצלחה: עדכנת את המשלוחים!';
$_['text_list'] = 'רשימת המשלוחים';

// Column
$_['column_name'] = 'שיטת משלוח';
$_['column_status'] = 'מצב';
$_['column_sort_order'] = 'סדר מיון';
$_['column_action'] = 'פעולה';

// Error
$_['error_permission'] = 'אזהרה: אין לך הרשאה לשינוי משלוחים!';

