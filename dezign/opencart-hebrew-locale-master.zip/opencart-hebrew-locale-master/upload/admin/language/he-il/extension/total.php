<?php
// Heading
$_['heading_title'] = 'סכומי ההזמנה';

// Text
$_['text_success'] = 'הצלחה: שינוי הסכומים!';
$_['text_list'] = 'רשימת הזמנה כוללת';

// Column
$_['column_name'] = 'סכומי ההזמנה';
$_['column_status'] = 'סטטוס';
$_['column_sort_order'] = 'סדר מיון';
$_['column_action'] = 'פעולה';

// Error
$_['error_permission'] = 'אזהרה: אין לך הרשאה לשינוי מוצרים!';

