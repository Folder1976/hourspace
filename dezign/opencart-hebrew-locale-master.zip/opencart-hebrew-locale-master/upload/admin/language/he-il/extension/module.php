<?php
// Heading
$_['heading_title'] = 'מודולים';

// Text
$_['text_success'] = 'הצלחה: שינוי מודולים!';
$_['text_layout'] = 'לאחר שהתקנת וקבעת תצורה מודול ניתן להוסיפו לפריסה <a href="%s" class="alert-link"> כאן</a>!';
$_['text_list'] = 'מודול רשימת';

// Column
$_['column_name'] = 'שם המודול';
$_['column_action'] = 'פעולה';

// Error
$_['error_permission'] = 'אזהרה: אין לך הרשאה לשינוי מוצרים!';

