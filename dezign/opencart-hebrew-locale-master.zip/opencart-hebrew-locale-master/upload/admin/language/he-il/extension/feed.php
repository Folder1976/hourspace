<?php
// Heading
$_['heading_title'] = 'פידים';

// Text
$_['text_success'] = 'הצלחה: שינוי פידים!';
$_['text_list'] = 'רשימת הֿפידים';

// Column
$_['column_name'] = 'שם הפיד של המוצר';
$_['column_status'] = 'סטטוס';
$_['column_action'] = 'פעולה';

// Error
$_['error_permission'] = 'אזהרה: אין לך הרשאה לשינוי מסננים!';

