<?php
// Heading
$_['heading_title'] = 'תשלומים';

// Text
$_['text_success'] = 'הצלחה: שינוי תשלומים!';
$_['text_list'] = 'רשימת קניות';

// Column
$_['column_name'] = 'שיטת התשלום';
$_['column_status'] = 'סטטוס';
$_['column_sort_order'] = 'סדר מיון';
$_['column_action'] = 'פעולה';

// Error
$_['error_permission'] = 'אזהרה: אין לך הרשאה לשינוי תשלומים!';

