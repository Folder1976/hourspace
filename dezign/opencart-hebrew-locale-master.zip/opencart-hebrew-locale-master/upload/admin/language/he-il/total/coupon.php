<?php
// Heading
$_['heading_title'] = 'קופון';

// Text
$_['text_total'] = 'סכומי ההזמנה';
$_['text_success'] = 'הצלחה: שינוי הכולל קופון!';
$_['text_edit'] = 'עריכת קופון';

// Entry
$_['entry_status'] = 'סטטוס';
$_['entry_sort_order'] = 'מיין לפי';

// Error
$_['error_permission'] = 'אזהרה: אין לך הרשאה לשינוי הכולל קופון!';

