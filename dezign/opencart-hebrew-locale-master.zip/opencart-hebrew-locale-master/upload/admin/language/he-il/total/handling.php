<?php
// Heading
$_['heading_title'] = 'דמי טיפול';

// Text
$_['text_total'] = 'סכומי ההזמנה';
$_['text_success'] = 'הצלחה: שינוי דמי טיפול הכולל!';
$_['text_edit'] = 'לערוך טיפול בתשלום סך';

// Entry
$_['entry_total'] = 'סכומי ההזמנה';
$_['entry_fee'] = 'עמלה';
$_['entry_tax_class'] = 'שיעור המס';
$_['entry_status'] = 'סטטוס';
$_['entry_sort_order'] = 'מיין לפי';

// Help
$_['help_total'] = 'סה כ הוצאה הסדר צריך להגיע לפני סיכום הזמנה זו הופכת לפעילה.';

// Error
$_['error_permission'] = 'אזהרה: אין לך הרשאה לשינוי דמי טיפול הכולל!';

