<?php
// Heading
$_['heading_title'] = 'אשראי בחנות';

// Text
$_['text_total'] = 'סכומי ההזמנה';
$_['text_success'] = 'הצלחה: שינית את סכום האשראי הכללי!';
$_['text_edit'] = 'עריכת סכום אשראי של החנות';

// Entry
$_['entry_status'] = 'סטטוס';
$_['entry_sort_order'] = 'מיין לפי';

// Error
$_['error_permission'] = 'אזהרה: אין לך הרשאה לשינוי סכום אשראי של החנות!';

