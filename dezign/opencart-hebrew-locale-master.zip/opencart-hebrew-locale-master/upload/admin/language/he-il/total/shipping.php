<?php
// Heading
$_['heading_title'] = 'משלוחים';

// Text
$_['text_total'] = 'סכומי ההזמנה';
$_['text_success'] = 'הצלחה: עדכנת את סך עלות המשלוחים!';
$_['text_edit'] = 'עריכת סך עלות המשלוח';

// Entry
$_['entry_estimator'] = 'מעריך עלות משלוח';
$_['entry_status'] = 'מצב';
$_['entry_sort_order'] = 'מיין לפי';

// Error
$_['error_permission'] = 'אזהרה: אין לך הרשאה לשינוי עלות דמי טיפול!';

