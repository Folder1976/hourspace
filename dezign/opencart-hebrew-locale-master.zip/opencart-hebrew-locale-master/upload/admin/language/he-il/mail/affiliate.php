<?php
// Text
$_['text_approve_subject'] = '%s - חשבון השותף שלך הופעל!';
$_['text_approve_welcome'] = 'ברוכים הבאים ותודה על ההרשמה ל- %s!';
$_['text_approve_login'] = 'החשבון שלך נוצר כעת, באפשרותך להיכנס באמצעות כתובת הדוא"ל והסיסמה שלך על-ידי כניסה לאתר האינטרנט שלנו או בכתובת ה-URL הבאה:';
$_['text_approve_services'] = 'בעת כניסה, יהיה באפשרותך ליצור קודי מעקב, מעקב אחר תשלומי העמלה ולערוך את פרטי החשבון שלך.';
$_['text_approve_thanks'] = 'תודה,';
$_['text_transaction_subject'] = '%s - עמלות שותפים';
$_['text_transaction_received'] = 'קיבלת %s עמלה!';
$_['text_transaction_total'] = 'את הסכום הכולל של הוועדה הוא כעת %s.';

