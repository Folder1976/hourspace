<?php
// Text
$_['text_subject'] = '%s - עדכון החזרה %s';
$_['text_return_id'] = 'מס׳ החזרה:';
$_['text_date_added'] = 'תאריך חזרה:';
$_['text_return_status'] = 'ההזמנה שלך עודכנה למצב הבא:';
$_['text_comment'] = 'ההערות להחזרה זו הינם:';
$_['text_footer'] = 'במידה ויש שאלות, ניתן להשיב למייל זה.';

