<?php
// Text
$_['text_approve_subject'] = '%s - חשבונך הופעל!';
$_['text_approve_welcome'] = 'ברוכים הבאים ותודה על ההרשמה ל- %s!';
$_['text_approve_login'] = 'החשבון שלך נוצר כעת, באפשרותך להיכנס באמצעות כתובת הדוא"ל והסיסמה שלך על-ידי כניסה לאתר האינטרנט שלנו או בכתובת ה-URL הבאה:';
$_['text_approve_services'] = 'עם כניסתך לאתר, באפשרותך יהיה לגשת לשירותים נוספים לרבות סקירת הזמנות עבר, הדפסת חשבוניות ועריכת פרטי החשבון שלך.';
$_['text_approve_thanks'] = 'תודה,';
$_['text_transaction_subject'] = '%s - חשבון אשראי';
$_['text_transaction_received'] = 'קיבלת %s זיכוי!';
$_['text_reward_subject'] = '%s - נקודות זיכוי';
$_['text_reward_received'] = 'קיבלת %s נקודות זיכוי!';
$_['text_reward_total'] = 'המספר הכולל של נקודות זיכוי הוא עכשיו %s.';

