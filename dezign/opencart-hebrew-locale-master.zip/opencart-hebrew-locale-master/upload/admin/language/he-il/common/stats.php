<?php$_['text_complete_status'] = 'הזמנות הושלמו';
$_['text_processing_status'] = 'הזמנות בביצוע';
$_['text_other_status'] = 'מצבים אחרים';

