<?php
// header
$_['heading_title'] = 'מנהל';

// Text
$_['text_heading'] = 'מנהל';
$_['text_login'] = 'אנא הזינו את פרטי ההתחברות.';
$_['text_forgotten'] = 'שכחתי סיסמא';

// Entry
$_['entry_username'] = 'שם משתמש';
$_['entry_password'] = 'סיסמא';

// Button
$_['button_login'] = 'התחבר';

// Error
$_['error_login'] = 'שם המשתמש ו/או הסיסמא לא תואמים.';
$_['error_token'] = 'חיבורך לא זוהה. אנא התחבר שוב.';

