<?php
// Heading
$_['heading_title'] = 'לוח מחוונים';

// Text
$_['text_order_total'] = 'סה"כ הזמנות';
$_['text_customer_total'] = 'סה"כ לקוחות';
$_['text_sale_total'] = 'סך הכל מכירות';
$_['text_online_total'] = 'מחוברים אונליין';
$_['text_map'] = 'מפת העולם';
$_['text_sale'] = 'ניתוח מכירות';
$_['text_activity'] = 'פעילות אחרונה';
$_['text_recent'] = 'הזמנות אחרונות';
$_['text_order'] = 'הזמנות';
$_['text_customer'] = 'לקוחות';
$_['text_day'] = 'היום';
$_['text_week'] = 'השבוע';
$_['text_month'] = 'החודש';
$_['text_year'] = 'השנה';
$_['text_view'] = 'הצג עוד..';

// Error
$_['error_install'] = 'אזהרה: תיקיית ההתקנה עדיין קיימת, יש למחוק אותה בשל סיבות אבטחה!';

