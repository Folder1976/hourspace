<?php
// Text
$_['text_version'] = 'גירסה %s';

