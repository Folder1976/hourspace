<?php
// Heading
$_['heading_title'] = 'OpenCart';

// Text
$_['text_order'] = 'הזמנות';
$_['text_order_status'] = 'ממתינה';
$_['text_complete_status'] = 'בוצע';
$_['text_customer'] = 'לקוחות';
$_['text_online'] = 'לקוחות מקוונים';
$_['text_approval'] = 'מחכה לאישור';
$_['text_product'] = 'מוצרים';
$_['text_stock'] = 'אזל מהמלאי';
$_['text_review'] = 'ביקורות';
$_['text_return'] = 'החזרות';
$_['text_affiliate'] = 'שותפים';
$_['text_store'] = 'חנויות';
$_['text_front'] = 'בחזית החנות';
$_['text_help'] = 'עזרה';
$_['text_homepage'] = 'עמוד בית';
$_['text_support'] = 'פורום תמיכה';
$_['text_documentation'] = 'מסמכים';
$_['text_logout'] = 'התנתק';

