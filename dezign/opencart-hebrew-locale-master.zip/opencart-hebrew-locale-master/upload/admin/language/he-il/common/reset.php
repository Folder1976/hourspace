<?php
// header
$_['heading_title'] = 'אפס את הסיסמה שלך';

// Text
$_['text_reset'] = 'אפס את הסיסמה שלך!';
$_['text_password'] = 'הזן את הסיסמה החדשה.';
$_['text_success'] = 'הצלחה: הסיסמה שלך עודכנה בהצלחה.';

// Entry
$_['entry_password'] = 'סיסמא';
$_['entry_confirm'] = 'אישור';

// Error
$_['error_password'] = 'הסיסמה צריכה להיות בין 11 ל 255 תווים!';
$_['error_confirm'] = 'שדה הסיסמה ואישור סיסמה אינם תואמים!';

