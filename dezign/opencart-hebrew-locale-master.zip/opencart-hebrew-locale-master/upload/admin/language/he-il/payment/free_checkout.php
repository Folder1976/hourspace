<?php
// Heading
$_['heading_title'] = 'הרכישה בחינם';

// Text
$_['text_payment'] = 'תשלום';
$_['text_success'] = 'הצלחה: שינית מודול התשלום!';
$_['text_edit'] = 'עריכת הרכישה בחינם';

// Entry
$_['entry_order_status'] = 'סטאטוס הזמנה';
$_['entry_status'] = 'סטטוס';
$_['entry_sort_order'] = 'מיון הזמנה';

// Error
$_['error_permission'] = 'הזהרה: אין הרשאות שינוי של פרטי רכישה בחינם!';

