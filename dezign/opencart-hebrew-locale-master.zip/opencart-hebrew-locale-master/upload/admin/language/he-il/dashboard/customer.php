<?php
// Heading
$_['heading_title'] = 'סה"כ לקוחות';

// Text
$_['text_view'] = 'הצג יותר...';

