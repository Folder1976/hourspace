<?php
// Heading
$_['heading_title'] = 'אנשים מחוברים';

// Text
$_['text_view'] = 'הצג יותר...';

