<?php
// Heading
$_['heading_title'] = 'ניתוח מכירות';

// Text
$_['text_order'] = 'הזמנות';
$_['text_customer'] = 'לקוחות';
$_['text_day'] = 'היום';
$_['text_week'] = 'השבוע';
$_['text_month'] = 'חודש';
$_['text_year'] = 'שנה';

