<?php
// Heading
$_['heading_title'] = 'סה"כ הזמנות';

// Text
$_['text_view'] = 'הצג יותר...';

