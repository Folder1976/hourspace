<?php
// Heading
$_['heading_title'] = 'מפת העולם';
$_['text_order'] = 'הזמנות';
$_['text_sale'] = 'מכירות';

