<?php
// Heading
$_['heading_title'] = 'הזמנות אחרונות';

// Column
$_['column_order_id'] = 'מספר הזמנה';
$_['column_customer'] = 'לקוח';
$_['column_status'] = 'מצב';
$_['column_total'] = 'סה״כ';
$_['column_date_added'] = 'תאריך הוספה';
$_['column_action'] = 'פעולה';

