<?php
// Heading
$_['heading_title'] = 'סך כל המכירות';

// Text
$_['text_view'] = 'הצג יותר...';

